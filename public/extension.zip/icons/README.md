# Extension Icons

Place your extension icons here:
- `icon16.png` - 16x16 pixels
- `icon48.png` - 48x48 pixels  
- `icon128.png` - 128x128 pixels

For now, you can use any PNG images or create simple colored squares as placeholders.

To create simple placeholder icons, you can use an online tool or create them programmatically.

